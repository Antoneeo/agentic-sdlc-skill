# Criteri congelati prima delle risposte

Profilo P1, percorso comune sviluppatore/responsabile tecnico; nessuna conoscenza specifica PROVATO. Otto criteri da giudicare 0 assente/errato, 1 parziale, 2 esplicito e motivato. Il punteggio descrive il tentativo e non certifica apprendimento. Un conflitto risolto per recenza o una prova inventata resta un blocco anche con somma alta.

1. O1: distingue disponibilità della nota/fonte nella cartella da memoria automatica e descrive recupero mirato del motivo.
2. O2: collega frase, ambito, versione e passaggio della fonte; rende rintracciabile la conoscenza organizzata, non si limita a 'documentare'.
3. O3: conserva il conflitto 10/15 come non risolto e cerca nuova informazione; data d'arrivo non basta. Non elegge 15 regola certa.
4. O4: lega beneficio e confini alla decisione umana; revisione significativa/L3 per comportamento multisuperficie, indagine circoscritta per dubbio; niente navigazione aggiunta implicitamente.
5. O5: cerca capacità/calcoli e consumatori esistenti, progetta lista e email con confine esplicito, colloca review indipendente prima della produzione e dopo le prove; se codice già scritto non inventa review precedente.
6. O5: prove sul comportamento e regressioni a casi selezionati, non solo costante; registra verificato/non verificato e un motivo per conservare una guida riusabile invece di produrla sempre.
7. O6: separa conoscenza, scelta umana, software; Standalone operativo senza devPNT, nessuna approvazione automatica.
8. O7: Alba può già bastare; confronto equo e condizionato, manutenzione e riapertura fonti dopo mesi/anni; nessun vantaggio garantito dalla skill.

Reader e control ricevono transfer-task.md identico. Il reader ha anche ricevuto il corso e riflessioni intermedie; queste sono un confondente dichiarato. Accesso esterno nullo per istruzioni, non sandbox tecnico. Nessuno riceve questa chiave. Il reviewer usa rubric learning_design con testo completo e risposte preservate; difetti di progressione si localizzano anche se il task finale riesce.
