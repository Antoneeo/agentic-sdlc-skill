# Registro della lettura sequenziale — Course 3

Per il revisore: usare questo registro per individuare le esposizioni effettive e le risposte originali. Il registro descrive conduzione, conteggi e difficoltà dichiarate; non assegna un esito didattico. I testi completi sono nei registri indicati.

## Esposizioni completate

| Stream | Lettore | Esposizione | Risposte conservate |
|---|---|---|---|
| Principale | `/root/course3_reading_conductor/reader` | S01–S34 packet-v1; S35–S52 packet-v2; poi transfer-task | 52 risposte alle unità e 1 risposta finale |
| Prefisso corretto | `/root/course3_reader_fresh_prefix` | S01–S13 packet-v2 | 4 risposte conservate dal root e 9 dal conductor |

Il principale è uno stream misto, non una lettura integrale della versione finale. S13 è stata letta in v1 dal principale e in v2 dal lettore separato del prefisso. Il principale non ha ricevuto S35–S52 in v1. I prompt v1 preparati ma non consegnati sono conservati in `reader-v1/undelivered-v1-prompts/`. Le successive correzioni editoriali v3 non sono state esposte da questo conductor.

Nel principale ogni risposta è stata letta e salvata prima della consegna successiva, sempre allo stesso lettore. Gli otto tentativi S11, S17, S23, S27, S38, S42, S47 e S50 precedono le rispettive soluzioni S12, S18, S24, S28, S39, S43, S48 e S51. Il compito finale è stato consegnato dopo la risposta a S52, senza criteri di valutazione o soluzioni aggiunte. Il prefisso separato include il tentativo S11 prima della soluzione S12 e termina dopo S13.

## Registri e isolamento

- `reader-v1/S01-prompt.txt` … `S52-prompt.txt` e corrispondenti `Sxx-response.txt`: testo consegnato e risposta di ogni unità principale.
- `reader-v1/exposure-manifest.json`: versione e SHA-256 del packet, del prompt e della risposta per ciascuna unità principale.
- `reader-v1/final-task-prompt.txt` e `reader-v1/final-task-response.md`: consegna finale e risposta separata.
- `fresh-prefix.md`: registro root delle prime quattro unità del lettore separato.
- `fresh-prefix-rest/S05-prompt.txt` … `S13-prompt.txt` e corrispondenti risposte: prosecuzione del prefisso effettuata dal conductor.
- `reader-v1/run-notes.txt`: ID, variazioni del protocollo e note di trasporto.

Il principale è stato creato con `fork_turns: none` e profilo P1: membro di un team software che usa agenti, conoscenza delle due skill non stabilita. Non ha ricevuto percorsi ai file, contenuti futuri, criteri o annotazioni dell’autore. L’isolamento era solo istruttivo: strumenti e file non erano tecnicamente disabilitati. Non sono state osservate chiamate a strumenti nel suo stream.

Il lettore separato era già stato creato dal root senza storia ereditata. Il registro delle prime quattro unità autorizza la lettura di un file packet per turno: questa modalità differisce dalla consegna inline del principale. Dal trasferimento al conductor, S05–S13 sono state consegnate inline; le risposte sono state inoltrate verbatim dal root perché le notifiche tornavano al parent originale. Nessun contenuto dei due lettori è stato passato all’altro.

## Difficoltà dichiarate e variazioni operative

Le risposte complete mantengono anche i riferimenti che il lettore non poteva ancora seguire, senza correggerli retroattivamente. Tra i punti dichiarati nel principale: termine skill in S03; modalità concreta di registrazione e limiti di lettura in S13; «risposta con provenienza» in S15; limiti L2 e significato operativo di review/chiusura in S26; percorso previsto per creare una GUIDE in S37. Queste sono osservazioni del lettore, senza valutazione del conductor.

Il principale segnala inoltre «A35» in S30 e «luglio,35» in S36. Il lettore separato, dopo S13 v2, dichiara non ancora mostrato come mantenere il collegamento preciso tra testo estratto e pagina dell’originale. Le segnalazioni sono state conservate e la lettura è proseguita senza suggerimenti di riparazione.

I prompt normalizzano CRLF in LF e separano il testo dell’unità dalla domanda neutra con due ritorni a capo. Un primo comando di registrazione ha incontrato un errore di parsing PowerShell; è stato ripetuto prima della successiva consegna, senza alterare il contenuto ricevuto dal lettore. Nessun file canonico del corso è stato modificato dal conductor. Il conteggio su disco conferma 52 risposte principali alle unità, una risposta finale e 9 risposte aggiunte al registro del prefisso.
