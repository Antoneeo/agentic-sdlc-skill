# Design gate — C-001, 3.0-content

Verdict: **PASS with warnings**. Scope: the proposed design for a complete 52-unit revision, before authoring. Independence: reviewer in a separate agent context, read-only on the course and design. This verdict does not assess unwritten learner content or human learning.

The new `design.md:35-37` names the graph, source register, 3.0 simulation evidence, and other affected files. It resolves the earlier scope omission at the design level. No blocking teaching, source, or testing defect is established before the 52 units exist.

## Warnings

1. **WARN — Align the canonical analysis during production.** The present ANALYSIS Impact still names 16 replacements and 2.1 evidence (`repo/ai_docs/solutions/ANALYSIS_course_agentic-sdlc-kb-agentic.md:87-94`), while `design.md:3,35-37` specifies 52 units and 3.0 artifacts. The design explicitly includes updating ANALYSIS, so this is no longer a missing-impact blocker. Make its operative scope and paths agree before the canonical course and evidence are treated as current; also update the 2.1 label in `sources.md:3` as planned.
2. **WARN — The method field-test output lacks a named place.** The approved Vision requires a verifiable account of what `course_creator` helped, what needed correction, and whether a repeatable method rule is implicated (`repo/ai_docs/vision/features/VISION_course_agentic-sdlc-kb-agentic.md:14,57`). `design.md:31-33,37` plans learner diagnostics and a general dossier, but does not explicitly map their findings into that account. Name its owning report or section and keep this distinct from efficacy claims. This can be completed alongside production.
3. **WARN — Preserve both learner-role viewpoints during M5/M6 authoring.** `repo/ai_docs/solutions/courses/agentic-sdlc-kb-agentic/D-UC.md:3` says examples name the developer and technical-lead perspectives when they diverge. `design.md:19,21` covers actors in Orione and human decisions but does not assign those two learner perspectives in a worked decision. Make the developer's evidence and the lead's benefit/scope judgment visible in the authored explanation. P1 remains one common path.

## Constraint trace

- **UC1 / Vision promise 1, folder and ordinary-agent comparison:** `design.md:11,29`; fair alternative and limits at `design.md:11,23`. **UC2 / promise 2, provenance and conflict:** `design.md:13-15,29`. **UC3 / promise 3, governed change:** `design.md:17-19,29`. **UC4 / promises 4 and 6, routing and accumulation:** `design.md:21-23,29`. **UC5 / promise 5, transfer to own project:** `design.md:21,29`; oral or private-note application follows `repo/ai_docs/solutions/ANALYSIS_course_agentic-sdlc-kb-agentic.md:41-43,68-69`.
- **C-1 source drift:** `design.md:7,33,37`. **C-2 unproved prerequisites:** `design.md:7,11,27,31`. **C-3 catalog in place of explanation:** `design.md:7,11-23,29`. **C-4 guaranteed time benefit:** `design.md:23,29`. **C-5 contaminated simulation:** `design.md:31,37`; instruction-only isolation is disclosed. **C-6 devPNT mistaken for prerequisite:** `design.md:21,29`. **C-7 absent feedback:** not altered by this design; `repo/ai_docs/solutions/courses/agentic-sdlc-kb-agentic/D-IC.md:12-14` remains the owning declaration.
- **Vision non-goals and limits:** fictional Orione and no real-project modification (`design.md:7,19,21`); no installation or PPTX now (`design.md:33`); no automated or human-efficacy claim (`design.md:7,23,31`); sources rather than model recall (`design.md:7,33`). The 52-unit plan is a credible progressive route, subject to actual passage-level and learner evidence after authoring.

## Verification boundary

The snapshot archive exists and its SHA-256 matches `sources.md:3`. The planned claim sequence aligns at design level with claim-1 through claim-13; this review did not validate any future sentence, answer, citation, or learner response. Review the complete learner surface with its graph, plan, source checks and frozen diagnostic evidence after authoring.
