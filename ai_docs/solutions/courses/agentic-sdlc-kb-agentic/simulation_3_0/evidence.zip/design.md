# C-001 — design della revisione 3.0-content

Per il reviewer indipendente prima della produzione: verificare la revisione del percorso contro la Vision approvata, non giudicare un corso ancora da scrivere. Autorità: ANALYSIS_course_agentic-sdlc-kb-agentic.md e la relativa Vision nella copia repo/. Questa specifica dettaglia il suo Action Plan. Budget: 52 unità, circa 70–150 parole visibili per unità; eccezioni motivate per domande cumulative e soluzioni. Ogni unità ha tutti i campi slide-content-v1. Il testo visibile deve essere autonomo; note e specifiche non colmano lacune del lettore.

## Contratto di scrittura

P1 è il percorso comune di sviluppatori e responsabili tecnici che usano agenti. Conoscenza delle due skill non accertata. Al termine deve motivare una risposta documentale e una modifica, distinguendo prova, ipotesi, scelta umana e lavoro residuo. Il testo risponde a come conservare e riusare ragioni e fonti nel lavoro reale; non insegna installazione o API dei client, né promette efficacia umana. Casi e documenti Orione sono fittizi e dichiarati tali. Le affermazioni sulle skill restano ancorate ai 13 claim e allo snapshot riapribile. Forma: racconto in sette moduli, una domanda locale per unità, titoli concreti, transizioni esplicite, soluzioni dopo il tentativo. Il renderer futuro non deve inventare contenuto.

## Percorso e conoscenza di ingresso/uscita

M1 S01–12: nessun prerequisito sulle skill. S01 descrive Orione, applicazione che attende la conferma del servizio esterno; oggi scade dopo 30 secondi e una nuova collega chiede perché. S02 introduce il vecchio manuale che motivava il numero, senza confonderlo con prova di validità attuale. S03 confronta nota insufficiente e nota con fonte/motivo/limite. S04 definisce skill come istruzioni riusabili, non memoria automatica. S05 assegna i due scopi. S06–10 spiegano contesto, cartella persistente, ai_docs, indici e riapertura mirata, confronto equo e verifica dell'esecuzione. S11 quesito guidato; S12 soluzione. Uscita: CO1 limite del contesto, CO2 consultazione persistente; CO11 definizione di skill, CO12 distinzione note/metodo. Nomi di documenti futuri non sono richiesti per rispondere.

M2 S13–18: ingresso CO2. Conservare fonte con versione, ricavare claim con ambito e locatore, organizzare in grafo degli argomenti, rispondere con citazione e limite. Il Manuale 2.1 §4.3 p.48, fittizio, attesta per le richieste standard Orione 30 secondi fino al 30 giugno. CO3 fonte/provenienza; CO4 claim, grafo e risposta. S17 check su notifica nuova e testo fonte completo, S18 soluzione. Non chiedere dati mai forniti.

M3 S19–24: ingresso CO4. Bollettino B dà 45 secondi per le richieste standard dal 1 luglio; nota C dà 30 nello stesso ambito. Distinguere variazione temporale e conflitto; entrambe le affermazioni contestate, nuova evidenza e aggiornamento dei riferimenti. Rettifica D esplicita che C riguarda richieste urgenti: standard 45 e urgenti30 dal1luglio possono coesistere. La variante controllata cambia l'ambito, non fa vincere la data. S23 check separato di trasferimento, S24 soluzione. Uscita CO5.

M4 S25–28: ingresso CO2, CO5 disponibile. Beneficio umano prima del numero, Vision con confini, triage L1/L2/L3/Spike ragionato sugli effetti. S27 confronto refuso/comportamento/incertezza e ampliamento non autorizzato, S28 soluzione. Uscita CO6. Evitare 'poche righe = L1'.

M5 S29–39: ingresso CO6. Introdurre prima attori e superfici concrete: operatore guarda il pannello, assistenza riceve notifica. S29 bisogno; S30 comportamento e confini temporali; S31 interazione; S32 rischi; S33 ispezione delle capacità e scelta riuso; S34 Impact e design anche nel caso di capacità assente; S35 review indipendente prima del codice; S36 implementazione e test osservabili; S37 review finale, chiusura e GUIDE con provenienza solo quando giustificata. S38 check con omissioni nel caso completo, S39 soluzione con recupero. Uscita CO7 analisi di bisogni/interazione/rischi, CO8 capacità/design/review/verifica/guide. Ogni fatto di codice è simulato, ogni test indicato è progettato e non eseguito su un progetto reale.

M6 S40–44: ingresso CO5 e CO8. Handoff dalla conoscenza al cambiamento; Standalone e aggiunta opzionale devPNT, sigle governate spiegate nel loro contesto senza richiederne memoria. S42 scenario nuovo e decisioni umane, S43 risposta. S44 applicazione facoltativa al proprio progetto, guidata dagli esempi precedenti e dai criteri, senza invio di documenti o modifiche. Uscita CO9.

M7 S45–52: ingresso CO9. Settimana, mese, anni: stesso compito e informazioni equivalenti per confronto con note curate. Costo di manutenzione, quando basta la nota, quando la disciplina riusabile aiuta. S47 check cumulativo, S48 soluzione; S49 perdita del beneficio senza consultazione; S50 caso nuovo autonomo, S51 soluzione; S52 chiusura e richiamo differito facoltativo. Uscita CO10, senza numeri di produttività né superiorità garantita.

## Verifiche fissate prima della produzione

Il grafo resta l'unica autorità dei prerequisiti. Aggiungere CO11/CO12 a M1 e una tabella di attraversamento con spiegazione e primo uso dipendente distinti, compreso l'ordine all'interno della slide. Gli altri CO mantengono identità e si precisano con sottolocatori per evitare che nomi presenti valgano per spiegazioni. Gli obiettivi O1–O7 e P1 restano invariati.

Criteri: O1 richiede cartella/accesso/consultazione e ragione con fonte, non 'salva tutto'; O2 fonte→claim con ambito→tema→risposta riapribile, non solo nome del file; O3 distingue ambiti e preserva incertezza, non 'vince il più recente'; O4 rischio e beneficio governano livello e confini, non numero di righe; O5 giustifica la sequenza e almeno una prova sul comportamento attraversando due superfici, non costante verde; O6 separa fatto documentale, scelta umana e modifica ed è attuabile Standalone; O7 confronta condizioni equivalenti e manutenzione senza vantaggi garantiti. Le domande detailed seguono questa evidenza, non il contrario.

Diagnosticare l'intera sequenza P1 con un lettore nuovo, una unità visibile per turno e risposta preservata prima della successiva. Le soluzioni seguono un tentativo, non anticipano la domanda; il pacchetto della prova finale non contiene chiave o note. Controllo senza corso separato con medesimo task finale e accesso. Un conductor può gestire le consegne, ma non suggerisce risposte e non emette verdetti. Reviewer distinto riceve fonte completa, grafo, piano, criteri e risultati. Limite: isolamento tramite istruzioni, non sandbox tecnico.

Verifica fonti sugli snapshot; struttura con course_check, poi index/check. Eventuali correzioni vengono provate su lettore fresco per il prefisso interessato; conservare la versione precedente. Consegna testo completo, export leggibile dei soli contenuti allievo e dossier di progettazione. Nessun PPTX, installazione o rilascio in questo passaggio.

## Impatto documentale

Riscrivere SLIDE_CONTENT, COURSE_PLAN, CONCEPT_GRAPH e SIMULATION_REPORT nel corso esistente; riallineare versione in D-IC e sources senza alterare lo snapshot delle fonti. Aggiornare ANALYSIS corrente, handoff C-001, record/log review e indici generati. D-UC e P-TM restano validi; nessuna modifica alla skill. Conservare gli esiti precedenti come storia e le nuove prove in simulation_3_0. Gli export sono viste derivate, non autorità alternative.
